package edu.berkeley.cs186.database.categories;

public interface Proj5Tests extends ProjTests  { /* category marker */ }