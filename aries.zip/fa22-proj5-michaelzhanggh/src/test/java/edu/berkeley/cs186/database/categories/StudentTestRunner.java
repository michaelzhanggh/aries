package edu.berkeley.cs186.database.categories;

public interface StudentTestRunner { /* category marker */ }
